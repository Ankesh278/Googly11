import 'package:flutter/material.dart';

import '../resourses/Image_Assets/image_assets.dart';

class HistoryDetailsView extends StatefulWidget {
  final dynamic price;
  final dynamic date;
  final dynamic transaction_Id;
  final dynamic status;
  final dynamic transaction_type;

  HistoryDetailsView({
    Key? key,
    required this.price,
    required this.date,
    required this.transaction_Id,
    required this.status,
    required this.transaction_type,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => _HistoryDetailsViewState();
}

class _HistoryDetailsViewState extends State<HistoryDetailsView> {
  int _currentStep = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'All Details Transaction',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        automaticallyImplyLeading: false,
        backgroundColor: Color(0xff780000),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 70,
            color: Color(0xFFE9F2F5),
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.only(left: 8, right: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("₹ ${widget.price}",
                          style: TextStyle(
                              color: _getStatusColor(widget.status),
                              fontSize: 20,
                              fontWeight: FontWeight.bold)),
                      Text("${getNameByStatus(widget.status)} : ${widget.date}",
                          style: TextStyle(color: Colors.black, fontSize: 14)),
                    ],
                  ),
                  if(widget.transaction_type.toString() == "withdraw-amount")
                    CircleAvatar(
                      backgroundColor: Colors.grey[300],
                      child: Image.asset(ImageAssets.banking,height: 30,width: 30,),
                    ),
                  if(widget.transaction_type.toString() == "deposits-contest")
                    CircleAvatar(
                      backgroundColor: Colors.grey[300],
                      child: Image.asset(ImageAssets.win),
                    ),
                  if(widget.transaction_type.toString() == "deposits-amount")
                    CircleAvatar(
                      backgroundColor: Colors.grey[300],
                      child: Image.asset(ImageAssets.withdrawal),
                    ),
                  if(widget.transaction_type.toString() == "deposits-bonus")
                    CircleAvatar(
                      backgroundColor: Colors.grey[300],
                      child: Image.asset(ImageAssets.bonusSummary),
                    ),
                  if(widget.transaction_type.toString() == "withdraw-contest")
                    CircleAvatar(
                      backgroundColor: Colors.grey[300],
                      child: Image.asset("assets/images/trophy.png"),
                    ),
                  if(widget.transaction_type.toString() == "withdraw-bonus")
                    CircleAvatar(
                      backgroundColor: Colors.grey[300],
                      child: Image.asset(ImageAssets.Logo_Googly11),
                    ),
                ],
              ),
            ),
          ),
          Container(
            height: 80,
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.only(left: 8, right: 8),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("To",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold)),
                  SizedBox(height: 15),
                  Text(widget.transaction_Id,
                      style: TextStyle(color: Colors.black, fontSize: 13)),
                ],
              ),
            ),
          ),
          Container(
            height: 80,
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.only(left: 8, right: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Transaction ID",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.bold)),
                      SizedBox(
                        height: 15,
                      ),
                      Text("${widget.transaction_Id}",
                          style: TextStyle(color: Colors.black, fontSize: 16)),
                    ],
                  ),
                  Container(
                    height: 35,
                    width: 85,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.black45, width: 1.5),
                        borderRadius: BorderRadius.all(Radius.circular(10))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Icon(Icons.copy, size: 17),
                        SizedBox(width: 10),
                        Text("COPY",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                                fontWeight: FontWeight.bold))
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15),
            child: Container(
              height: 150,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                border: Border.all(color: Colors.grey, width: 1),
              ),
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildStep("Request Raised", "${widget.date}",
                        _currentStep >= 0),
                    Divider(thickness: 2, color: Colors.grey),
                    _buildStep("Deposit Successful", "${widget.date}",
                        _currentStep >= 0),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildStep(String title, String subTitle, bool isComplete) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(color: Colors.black, fontSize: 12),
          ),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  subTitle,
                  style: TextStyle(color: Colors.black, fontSize: 12),
                ),
                if (isComplete)
                  Icon(
                    Icons.check,
                    color: Colors.green,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case "pending":
        return Colors.amber;
      case "canceled":
        return Colors.red;
      case "completed":
        return Colors.green;
      default:
        return Colors.black; // Default color or any other color you prefer
    }
  }

  String getNameByStatus(String status) {
    switch (status) {
      case "pending":
        return "Pending";
      case "canceled":
        return "Canceled";
      case "completed":
        return "Completed";
      default:
        return "Completed"; // Default color or any other color you prefer
    }
  }
}
