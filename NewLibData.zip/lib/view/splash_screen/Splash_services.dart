import 'dart:async';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:world11/bottom_navigation_bar/bottom_navigation_screen.dart';
import 'package:world11/bottom_navigation_bar/home_screen.dart';
import '../loginView/login_view.dart';
import '../loginView/user_login_sharredpreffrence/user_login_sharredprefrence.dart';
class SplashServices {

}
