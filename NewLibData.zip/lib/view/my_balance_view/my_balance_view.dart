import 'package:flutter/material.dart';

import '../../App_Widgets/CustomText.dart';

class MyBalanceView extends StatefulWidget {
  const MyBalanceView({Key? key}) : super(key: key);

  @override
  State<MyBalanceView> createState() => _MyBalaceViewState();
}

class _MyBalaceViewState extends State<MyBalanceView> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: Text('My Balance',style: TextStyle(
          color: Colors.white,
        ),),
        backgroundColor: Color(0xff780000),
      ),
      body: Column(
        children: [
          Container(
            height:size.height *0.4 ,
            width: double.infinity,
            decoration: BoxDecoration(
              color :Colors.grey,
            ),
            child: Column(
              children: [
                Text('TOTAL BALANCE',style: TextStyle(
                 color: Color(0xff780000),
                  fontWeight: FontWeight.bold
                ),),
                Text('₹ 34'),
                ElevatedButton(onPressed: (){},style: ButtonStyle(
                ), child: Text('ADD CASH'),),
               Divider(
                 color: Colors.white,
                 thickness: 1,
               ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomPaddedText(
                            text: 'AMOUNT ADDED (UNUTIL.ISED)'),
                        CustomPaddedText(
                            text: '₹ 34'),
                      ],
                    ),
                    Icon(Icons.info_outline_rounded)
                  ],
                ),
                Divider(
                  color: Colors.white,
                  thickness: 1,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        CustomPaddedText(
                            text: 'WINNING '),
                        CustomPaddedText(
                            text: '0 '),
                      ],
                    ),
                    Icon(Icons.info_outline_rounded)
                  ],
                ),
                Divider(
                  color: Colors.white,
                  thickness: 1,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        CustomPaddedText(
                            text: 'CASH BONUS'),
                        CustomPaddedText(
                            text: '0'),
                      ],
                    ),
                    Icon(Icons.info_outline_rounded)
                  ],
                ),
                Container(
                  height: size.height *.05,
                  width: size.width *.9,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      width: 2,
                      color: Colors.green,
                    ),
                  ),
                 child: Column(
                   crossAxisAlignment: CrossAxisAlignment.start,
                   mainAxisAlignment: MainAxisAlignment.start,
                   children: [
                    Row(
                      children: [
                        Icon(Icons.money,color: Colors.green,),
                        CustomPaddedText(text: 'Maximum usable Cash Bonus per Match = 100% \n of Entry Fees',style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 12
                        ),),
                      ],
                    ),
                   ],
                 ),
                ),
              ],
            ),
          ),
          SizedBox(height: 10),
          Container(
            height: size.height *.08,
            width: size.width *.9,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color :Colors.grey,
            ),
            child: Row(
             mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text('My Transaction'),
                Icon(Icons.chevron_right)
              ],
            ),
          ),
          SizedBox(height: 10),
          Container(
            height: size.height *.08,
            width: size.width *.9,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color :Colors.grey,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('My Transaction'),
                    Text('Add/Remove Card, Walletl,ets',style: TextStyle(
                      color: Colors.white
                    ),)
                  ],
                ),
                Icon(Icons.chevron_right)
              ],
            ),
          ),
          SizedBox(height: 10),
          Container(
            height: size.height *.08,
            width: size.width *.9,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color :Colors.grey,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text('My Transaction'),
                Icon(Icons.chevron_right)
              ],
            ),
          ),
          SizedBox(height: 10),
          Container(
            height: size.height *.08,
            width: size.width *.9,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color :Colors.grey,
            ),
            child: Row(

              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('My Transaction'),
                    Text('Invite a Friend and earn Upt0 500 Rupe cash',style: TextStyle(
                      color: Colors.white
                    ),),
                  ],
                ),
                Icon(Icons.chevron_right)
              ],
            ),
          ),
        ],
      ),
    );
  }
}
