import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:world11/view/OtpVerifyAadhaar.dart';
import '../Model/AadharVerificationModel/AadharCardVerification.dart';

class KYC_Verification extends StatefulWidget {
  const KYC_Verification({super.key});

  @override
  State<KYC_Verification> createState() => _KYC_VerificationState();
}

class _KYC_VerificationState extends State<KYC_Verification> {
  TextEditingController textController = TextEditingController();
  bool isButtonEnabled = false;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    textController.addListener(_checkInputLength);
  }

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  void _checkInputLength() {
    setState(() {
      isButtonEnabled = textController.text.length == 12;
    });
  }

  Future<AadharVerification> callAPI(String input) async {
    print("number"+input);
    final String apiUrl = 'https://api.emptra.com/aadhaarVerification/requestOtp';

    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'clientId': '9899a03dbe943a4b8cfbf42b6dffe329:f10777d9177394b0b52aa4fa623aba7d',
      'secretKey': 'sw1PRticKzthNupFgSfMnVKIBTtaJMDyeW2PZK6zPbGg3JCNAHvI7zHeMD8aAkeh0',
    };

    print("headers"+headers.toString());
    final Map<String, String> body = {
      'aadhaarNumber': input,
    };
    print("body"+body.toString());
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: headers,
      body: jsonEncode(body),
    );
    print("response"+response.bodyBytes.toString());
    print("response"+response.body.toString());
    if (response.statusCode == 200) {
      final aadharVerification = AadharVerification.fromJson(json.decode(response.body));
      if (aadharVerification.code == 100 && aadharVerification.result!.success == true && aadharVerification.result!.messageCode == "success") {
        Fluttertoast.showToast(msg: "Your Aadhaar number is valid otp send on your registered number",fontSize: 15,backgroundColor: Colors.green,textColor: Colors.white);
        Navigator.push(context, MaterialPageRoute(builder: (context)=> OtpScreen(client_Id: aadharVerification.result!.data!.clientId,)));
      } else  if (aadharVerification.code==500) {
        Fluttertoast.showToast(msg: "Your Aadhaar number is Invalid. Please enter the correct number",fontSize: 15,backgroundColor: Colors.green,textColor: Colors.white);

      }
      return aadharVerification;
    }
    else if (response.statusCode == 401) {
      final aadharVerification = AadharVerification.fromJson(json.decode(response.body));
      if ( aadharVerification.result!.success==false && aadharVerification.result!.messageCode == "invalid_token") {
        Fluttertoast.showToast(
          msg:  "Something went wrong, please try again",
          toastLength: Toast.LENGTH_LONG, // You can change the duration
          gravity: ToastGravity.BOTTOM, // You can change the position
          timeInSecForIosWeb: 1, // Time in seconds for iOS and web
          backgroundColor: Colors.pinkAccent,
          textColor: Colors.white,
          fontSize: 15.0,
        );
      }
      return aadharVerification;
    } else {
      throw Exception('Failed to call API');
    }
  }

  bool _isFocused = true;
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text('KYC Verification',style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),),
        automaticallyImplyLeading: false, // Set this to false to hide the default back button
        backgroundColor: Color(0xff780000),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            // Add your back button functionality here
            Navigator.of(context).pop(); // This example assumes you want to navigate back
          },
        ),
      ),
      body: Container(
        width: double.infinity,
         child: Column(
           children: [
             Padding(
               padding: const EdgeInsets.only(left: 15,top: 25),
               child: Align(
                 alignment: Alignment.topLeft,
                 child: Text(
                   "Enter Aadhaar Number",
                   style: TextStyle(fontStyle: FontStyle.normal,
                       fontSize: 15,
                       color: Colors.black,
                       fontWeight: FontWeight.w600
                   ),
                 ),
               ),
             ),
             Padding(
               padding: const EdgeInsets.only(left: 15, right: 15, top: 20),
               child: Form(
                 key: _formKey,
                 child: Column(
                   children: [
                     TextFormField(
                       controller: textController,
                       decoration: InputDecoration(
                         hintText: 'XXXX XXXX XXXX',
                         labelText: _isFocused ? 'Enter Aadhaar Number' : '',
                         labelStyle: TextStyle(
                           color: _isFocused ? Colors.blue : Colors.grey,
                         ),
                         focusedBorder: OutlineInputBorder(
                           borderSide: BorderSide(color: Colors.blueAccent, width: 1.5),
                         ),
                         enabledBorder: OutlineInputBorder(
                           borderSide: BorderSide(color: Colors.grey),
                         ),
                         errorBorder: OutlineInputBorder(
                           borderSide: BorderSide(color: Colors.red),
                         ),
                         errorStyle: TextStyle(color: Colors.red),
                       ),
                       onTap: () {
                         setState(() {
                           _isFocused = true;
                         });
                       },
                       maxLength: 12,
                       keyboardType: TextInputType.number,
                       validator: (value) {
                         if (value == null || value.isEmpty) {
                           return 'Please enter a 12-digit Aadhaar number.';
                         } else if (value.length != 12) {
                           return 'Aadhaar Card number must be 12 digits long.';
                         }
                         return null;
                       },
                     ),

                   ],
                 ),
               ),
             ),
             ElevatedButton(
               onPressed: isButtonEnabled ? _onButtonPressed : null,
               child: Text('Submit'),
               style: ElevatedButton.styleFrom(
                 backgroundColor: isButtonEnabled ? Colors.blue : Colors.grey,
               ),
             ),
           ],
         ),
      ),
    );
  }
  void _onButtonPressed() {
    if (_formKey.currentState!.validate()) {
          callAPI(textController.text);
    }
  }

}
