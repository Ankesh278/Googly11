import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../Model/PlayersTeamCreationResponse/PlayersData.dart';

class LiveTeamPreview extends StatefulWidget {
  final List<PlayersData_> batsmen;
  final List<PlayersData_> bowlers;
  final List<PlayersData_> wicketkeeper;
  final List<PlayersData_> allrounders;
  final List<String> Wk_points_Data;
  final List<String> Bat_points_Data;
  final List<String> AR_points_Data;
  final List<String> Bowl_points_Data;
  var captain;
  var vice_captain;
  var total_points;
  var time_hours;
  LiveTeamPreview({
    required this.batsmen,required this.bowlers,required this.allrounders,
    required this.wicketkeeper,required this.Wk_points_Data,required this.Bat_points_Data,
    required this.AR_points_Data,required this.Bowl_points_Data,
    required this.time_hours
  });
  @override
  State<LiveTeamPreview> createState() => _TeamPreviewState();
}

class _TeamPreviewState extends State<LiveTeamPreview> {

  TextStyle points_style = GoogleFonts.mcLaren(color: Colors.white,fontSize: 10);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        backgroundColor: Color(0xff780000),
        title: Column(
          children: [
            Text(
              'Team Preview',
              style: TextStyle(
                fontSize: 14,
                color: Colors.white,
              ),
            ),
          widget.time_hours != null && widget.time_hours != "0" ?  CountdownTimerWidget(time: widget.time_hours,) :Text("Live",)
          ],
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.question_mark,color: Colors.white,), // Replace 'Icons.info' with your desired icon
            onPressed: () {

            },
          ),
        ],
      ),
      body: Container(
        child: Column(
          children: [
            Expanded(
              child: Container(
                constraints: BoxConstraints.expand(),
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/images/ground.jpg"),
                      fit: BoxFit.cover),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundImage: AssetImage('assets/images/wk.jpg'),
                            backgroundColor: Colors.white,
                            radius: 10,
                          ),
                          SizedBox(width: 8,),
                          Text('Wicketkeeper',
                            style: GoogleFonts.mcLaren( fontSize: 12,
                                color: Colors.white,
                                fontWeight: FontWeight.bold
                            ),
                          ),

                        ],
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          for(int i=0;i<widget.wicketkeeper.length;i++)
                            player_icon(player: widget.wicketkeeper, i: i,player_type: 'wk', points_teamData: widget.Wk_points_Data,),
                        ],
                      ),
                      SizedBox(height:5),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundImage: AssetImage('assets/images/bat.jpg'),
                            backgroundColor: Colors.white,
                            radius: 10,
                          ),
                          SizedBox(width: 8,),
                          Text('Batsmen',
                            style: GoogleFonts.mcLaren( fontSize: 12,
                                color: Colors.white,
                                fontWeight: FontWeight.bold
                            ),
                          ),

                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          for(int i=0;i<widget.batsmen.length;i++)
                            player_icon(player: widget.batsmen, i: i,player_type: 'bat', points_teamData: widget.Bat_points_Data,),
                        ],
                      ),

                      SizedBox(height:5),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundImage: AssetImage('assets/images/bat_ball.jpg'),
                            backgroundColor: Colors.white,
                            radius: 10,
                          ),
                          SizedBox(width: 8,),
                          Text('All-rounders',
                            style: GoogleFonts.mcLaren(fontSize: 12,
                                color: Colors.white,
                                fontWeight: FontWeight.bold
                            ),
                          ),

                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          for(int i=0;i<widget.allrounders.length;i++)
                            player_icon(player: widget.allrounders, i: i,player_type: 'bat_ball', points_teamData: widget.AR_points_Data,),
                        ],
                      ),

                      SizedBox(height:5),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundImage: AssetImage('assets/images/ball.jpg'),
                            backgroundColor: Colors.white,
                            radius: 10,
                          ),
                          SizedBox(width: 8,),
                          Text('Bowlers',
                            style: GoogleFonts.mcLaren( fontSize: 12,
                                color: Colors.white,
                                fontWeight: FontWeight.bold
                            ),
                          ),

                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          for(int i=0;i<widget.bowlers.length;i++)
                            player_icon(player: widget.bowlers, i: i,player_type: 'ball', points_teamData: widget.Bowl_points_Data,),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class player_icon extends StatelessWidget {
  const player_icon({
    Key? key,
    required this.player,
    required this.i,
    required this.player_type,
    required this.points_teamData
  }) : super(key: key);

  final List<PlayersData_> player;
  final List<String> points_teamData;
  final int i;
  final String player_type;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Center(
          child: CircleAvatar(
              radius: 20,
              backgroundImage: NetworkImage(player[i].image)
          ),
        ),
        Container(
          padding: EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Text(
            player[i].name,
            style: GoogleFonts.mcLaren(
              fontSize: 7,
              color: Colors.white,
            ),
          ),
        ),
        SizedBox(height: 3,),
        Container(
          padding: EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Text( "${points_teamData[i].isNotEmpty ? points_teamData[i].toString() : "0"} points",
            style: GoogleFonts.mcLaren(
              fontSize: 7,
              color: Colors.white,
            ) ,
          ),
        ),
      ],
    );
  }
}

class CountdownTimerWidget extends StatefulWidget {
  final String time;

  CountdownTimerWidget({required this.time});

  @override
  _CountdownTimerWidgetState createState() => _CountdownTimerWidgetState();
}
class _CountdownTimerWidgetState extends State<CountdownTimerWidget> {
  late Timer _timer;
  late Duration _remainingTime;

  @override
  void initState() {
    super.initState();

    // Parse the provided time string to get the target time
    DateTime targetTime = DateTime.fromMillisecondsSinceEpoch(int.parse(widget.time));

    // Calculate the remaining time
    _remainingTime = targetTime.difference(DateTime.now());

    // Start a timer to update the UI every second
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        // Check if the remaining time is greater than 0
        if (_remainingTime.inSeconds > 0) {
          _remainingTime = targetTime.difference(DateTime.now());
        } else {
          timer.cancel();
          _remainingTime = Duration(seconds: 0);
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    String formattedTime = _formatDuration(_remainingTime);

    return Text(
      formattedTime,
      style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
    );
  }

  @override
  void dispose() {
    _timer.cancel(); // Cancel the timer when the widget is disposed
    super.dispose();
  }
  String _formatDuration(Duration duration) {
    if (duration.inDays > 0) {
      // Format the date along with the time
      DateTime targetDate = DateTime.now().add(duration);
      String formattedDate = DateFormat('dd MMM yyyy').format(targetDate);
      return '$formattedDate';
    } else if (duration.inHours > 0) {
      return '${duration.inHours}h : ${(duration.inMinutes % 60).toString().padLeft(2, '0')}m : ${(duration.inSeconds % 60).toString().padLeft(2, '0')}s';
    } else {
      return '${duration.inMinutes}m : ${(duration.inSeconds % 60).toString().padLeft(2, '0')}s';
    }
  }

}