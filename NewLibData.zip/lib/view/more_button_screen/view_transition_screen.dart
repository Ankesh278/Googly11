import 'package:flutter/material.dart';
import 'package:world11/App_Widgets/CustomText.dart';
import 'package:world11/App_Widgets/row_coloum_of_more_page_Widget.dart';
import 'package:world11/resourses/Image_Assets/image_assets.dart';
import 'package:world11/view/historyScreen.dart';

class ViewTransitionScreen extends StatefulWidget {
  const ViewTransitionScreen({Key? key}) : super(key: key);

  @override
  State<ViewTransitionScreen> createState() => _ViewTransitionScreenState();
}

class _ViewTransitionScreenState extends State<ViewTransitionScreen> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff780000),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomPaddedText(text: 'Hello Charine tom,',style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomPaddedText(text: 'Your Available Balance',style: TextStyle(
                color: Color(0xff780000),
              ),),
              Text('₹4587.400',style: TextStyle(

                color: Color(0xff780000),
                fontWeight: FontWeight.bold,
                fontSize: 18,
               decoration: TextDecoration.underline,
              ),),
              SizedBox(width: 1,),
            ],
          ),

          SizedBox(height: size.height *0.01,),
          Container(
            margin: EdgeInsets.only(left: 22),
            alignment: Alignment.center,
            height: size.height *0.1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ,
            width: size.width *0.9,
            decoration: BoxDecoration(
              color: Color(0xff780000).withOpacity(0.10),
              borderRadius: BorderRadius.circular(10)
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                RowNColumn(icon: Icons.remove_from_queue,text: 'Transfer',),
                RowNColumn(icon: Icons.vertical_align_top, text:'Top Up',),
                InkWell(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>HistoryScreen()));
                  },
                    child: RowNColumn(icon: Icons.history, text:'History',)),
              ],
            ),
          ),
          CustomPaddedText(text: 'Payment List',style: TextStyle(
            fontWeight: FontWeight.bold,
          ),),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [

              RowNColumn(icon: Icons.send_to_mobile_sharp, text: 'Send money',),
              RowNColumn(icon: Icons.add_card_outlined, text: 'Add money',),
              RowNColumn(icon: Icons.call_to_action_sharp, text: 'Cash out',),
            ],
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              RowNColumn(icon: Icons.paypal, text: 'Pay bill',),
              RowNColumn(icon: Icons.energy_savings_leaf, text: 'Savings',),
              RowNColumn(icon: Icons.more_horiz_sharp, text: 'More',),
            ],
          ),
          CustomPaddedText(text: 'My Offer',style: TextStyle(
            fontWeight: FontWeight.bold,
          ),),
          SizedBox(height: size.height *0.02,),
          Container(
            margin: EdgeInsets.only(left: 22),
            height: size.height * 0.2,
            width: size.width *0.9,
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  spreadRadius: 1,
                  blurRadius: 1,
                  color: Colors.grey.withOpacity(0.10),
                ),
              ],
              image: DecorationImage(image: NetworkImage(
                'https://img.freepik.com/premium-vector/happy-family-saving-money_179970-4556.jpg?w=2000',
              ),fit: BoxFit.cover),
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ],
      ),
    );
  }
}
