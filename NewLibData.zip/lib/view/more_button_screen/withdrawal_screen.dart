import 'package:flutter/material.dart';
import 'package:world11/App_Widgets/CustomText.dart';
import 'package:world11/App_Widgets/row_coloum_of_more_page_Widget.dart';
import 'package:world11/App_Widgets/row_custom.dart';

class WithdrawalScreen extends StatefulWidget {
  const WithdrawalScreen({Key? key}) : super(key: key);

  @override
  State<WithdrawalScreen> createState() => _WithdrawalScreenState();
}
double withdrawalAmount = 0.0;
class _WithdrawalScreenState extends State<WithdrawalScreen> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff780000),
      ),
      body: Column(
        children: [
          SizedBox(height: size.height *0.02,),
          Container(
            height: size.height *0.15,
            width: size.width *0.8,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Color(0xff780000).withOpacity(0.10),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: size.height *0.01,),
                CustomPaddedText(text: 'Total Balance',style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Colors.grey,
                ),),
                CustomRow(
                  image: Image(image: NetworkImage(
                      'https://cdn-icons-png.flaticon.com/512/1163/1163455.png'
                  ),height: size.height *0.07,),
                  text: '32,463.023',style: TextStyle(
                  fontSize: 22,
                  decoration: TextDecoration.underline,
                  fontWeight: FontWeight.bold,
                  color: Color(0xff780000),
                ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Enter Withdrawal Amount',
                  style: TextStyle(fontSize: 20),
                ),
                SizedBox(height: 20),
                TextField(
                  keyboardType: TextInputType.number,
                  onChanged: (value) {
                    setState(() {
                      withdrawalAmount = double.tryParse(value) ?? 0.0;
                    });
                  },
                  decoration: InputDecoration(
                    labelText: 'Amount',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    if (withdrawalAmount > 0) {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: Text('Withdrawal Successful'),
                          content: Text('You have withdrawn $withdrawalAmount USD.'),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('OK'),
                            ),
                          ],
                        ),
                      );
                    } else {
                      // Display an error message if the withdrawal amount is invalid
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: Text('Error'),
                          content: Text('Invalid withdrawal amount.'),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('OK'),
                            ),
                          ],
                        ),
                      );
                    }
                  },
                  child: Text('Withdraw'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
