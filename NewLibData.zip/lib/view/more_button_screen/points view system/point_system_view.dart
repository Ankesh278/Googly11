import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:world11/view/more_button_screen/points%20view%20system/points%20view%20controller.dart';

import '../../../resourses/Image_Assets/image_assets.dart';



class PointSystemView extends StatefulWidget {
  const PointSystemView({Key? key}) : super(key: key);

  @override
  State<PointSystemView> createState() => _PointSystemViewState();
}


class _PointSystemViewState extends State<PointSystemView> {
  final SportsController _sportsController = Get.put(SportsController());
  String selectedSport = '';
  String selectedTextcolor = '';


  @override
  Widget build(BuildContext context) {


    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('GOOGLY 11',style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),),
        automaticallyImplyLeading: true,
        backgroundColor: Color(0xff780000),
      ),

      body: Column(
        children: [
          SizedBox(height: size.height *0.02,),
          Container(
            height: size.height *0.06,
            width: size.width *5,
            decoration: BoxDecoration(
              color: Colors.orangeAccent.shade100.withOpacity(0.5),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // ElevatedButton(
                //   onPressed: () {
                //   },
                //   child: Text('Cricket'),
                // ),
                SizedBox(height: 50),

                InkWell(
                  onTap: () {
                    setState(() {
                      selectedSport = 'cricket';
                      _sportsController.showSport('cricket');
                    });
                  },
                  child: Container(
                    height: size.height * 0.03,
                    width: size.width * 0.2,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),

                      color: selectedSport == 'cricket' ? Color(0xff780000) : Colors.white,
                    ),
                    child: Center(child: Text('Cricket')),
                  ),
                ),



                // ElevatedButton(
                //   onPressed: () {
                //     _sportsController.showSport('football');
                //   },
                //   child: Text('Football'),
                // ),
                SizedBox(height: 50),

                InkWell(
                  onTap: () {
                    setState(() {
                      selectedSport = 'football';
                      _sportsController.showSport('football');
                    });
                  },
                  child: Container(
                    height: size.height * 0.03,
                    width: size.width * 0.2,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: selectedSport == 'football' ? Color(0xff780000) : Colors.white,
                    ),
                    child: Center(child: Text('Football')),
                  ),
                ),


                SizedBox(height: 50),

                InkWell(
                  onTap: () {
                    setState(() {
                      selectedSport = 'kabaddi';
                      _sportsController.showSport('kabaddi');
                    });
                  },
                  child: Container(
                    height: size.height * 0.03,
                    width: size.width * 0.2,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: selectedSport == 'kabaddi' ? Color(0xff780000) : Colors.white,
                    ),
                    child: Center(child: Text('Kabbadi',)),
                  ),
                ),



                // ElevatedButton(
                //   onPressed: () {
                //     _sportsController.showSport('kabaddi');
                //   },
                //   child: Text('Kabaddi'),
                // ),
                SizedBox(height: 50),

              ],
            ),
          ),

          SizedBox(height: 40,),



          Obx(() {
            if (_sportsController.visibleSport.value == 'football') {
              return Card(
                elevation: 3,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.blueAccent.shade100.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  height:size.height *.4,
                  width: size.width *.9,

                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text('T20'),
                          Text('ODI'),
                          Text('TEST'),
                          Text('T10'),

                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                    Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('BATTING',style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),),
                        Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                      ],
                    ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('BOWLING',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('FIELDING',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                        ],
                      ),
                      Divider(
                thickness: 1,
                color: Colors.grey,
                ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('STRIKE RATE',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('ECONOMY RATE',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),
                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('OTHERS',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                        ],
                      ),
                      Text('football')
                    ],
                  ),
                ),
              );
            } else {
              return SizedBox.shrink();
            }
          }),



          Obx(() {
            if (_sportsController.visibleSport.value == 'kabaddi') {
              return ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Card(
                  elevation: 3,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.orangeAccent.shade100.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    height:size.height *.4,
                    width: size.width *.9,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text('T20'),
                            Text('ODI'),
                            Text('TEST'),
                            Text('T10'),


                          ],
                        ),
                        Divider(
                          thickness: 1,
                          color: Colors.grey,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('BATTING',style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),),
                            Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                          ],
                        ),
                        Divider(
                          thickness: 1,
                          color: Colors.grey,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('BOWLING',style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),),
                            Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                          ],
                        ),
                        Divider(
                          thickness: 1,
                          color: Colors.grey,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('FIELDING',style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),),
                            Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                          ],
                        ),
                        Divider(
                          thickness: 1,
                          color: Colors.grey,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('STRIKE RATE',style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),),
                            Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                          ],
                        ),
                        Divider(
                          thickness: 1,
                          color: Colors.grey,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('ECONOMY RATE',style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),),
                            Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),
                          ],
                        ),
                        Divider(
                          thickness: 1,
                          color: Colors.grey,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('OTHERS',style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),),
                            Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            } else {
              return SizedBox.shrink();
            }
          }),



          Obx(() {
            if (_sportsController.visibleSport.value == 'cricket') {
              return Card(
                elevation: 3,
                child: Container(
                  height:size.height *.4,
                  width: size.width *.9,
                  decoration: BoxDecoration(
                    color: Colors.redAccent.shade100.withOpacity(0.5),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text('T20'),
                          Text('ODI'),
                          Text('TEST'),
                          Text('T10'),
                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('BATTING',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('BOWLING',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('FIELDING',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('STRIKE RATE',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),

                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('ECONOMY RATE',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),
                        ],
                      ),
                      Divider(
                        thickness: 1,
                        color: Colors.grey,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('OTHERS',style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),),
                          Image(image: AssetImage(ImageAssets.plus),height: 25,width: 25,),
                        ],
                      ),
                      Text('cricket')
                    ],
                  ),
                ),
              );
            } else {
              return SizedBox.shrink();
            }
          }),

        ],
      ),
    );
  }
}

