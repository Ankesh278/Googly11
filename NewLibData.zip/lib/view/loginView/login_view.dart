import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:world11/view/loginView/OtpLoginModel/LoginOtpModel.dart';
import 'package:world11/view/loginView/Otp_screen.dart';
import '../../App_Widgets/CustomText.dart';
import '../../bottom_navigation_bar/bottom_navigation_screen.dart';
import '../../resourses/Image_Assets/image_assets.dart';
import 'package:http/http.dart' as http;

import 'google_signin_api.dart';

class LoginView extends StatefulWidget {
   var user;
   LoginView({Key? key,  this.user}) : super(key: key);

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {

  final _loginKey = GlobalKey<FormState>();
  bool _isLoading = false;

  final TextEditingController _phoneController = TextEditingController();
  bool isAgeConfirmed = false;
  bool receiveUpdates = false;
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body:Stack(
        children: [
          SizedBox(
            height: double.infinity,
            width: double.infinity,
            child: Image(image: AssetImage(ImageAssets.bagroundImage),fit: BoxFit.cover,),
          ),

          Align(
            alignment: Alignment.center,
            child: Container(
                height: size.height *0.359335380325,
                width: size.width *.8,
                decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.4),
                ),
              child: Column(
                children: [
                  SizedBox(height: 15,),
                 CustomPaddedText(
                     text: 'Login/Register',style: TextStyle(
                   fontWeight: FontWeight.bold,
                   color: Colors.white,
                   fontSize: 16
                 ),),
                  SizedBox(height: 15,),
                Form(
                  key: _loginKey,
                  child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 6,right: 6),
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(10))
                        ),
                        height: 40, // Set your desired height
                        // Set your desired width
                        child: TextFormField(
                          controller: _phoneController,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your mobile number'  ;
                            }
                            return null;
                          },
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            contentPadding: EdgeInsets.all(10), // Adjust content padding if needed
                            border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.blueGrey),
                            ),
                            prefixIcon: Icon(Icons.phone, color: Colors.black,size: 15),
                            hintText: "Enter mobile number"
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

                  SizedBox(height: 20),
                  Row(
                    children: [
                      Checkbox(
                        fillColor: MaterialStateProperty.resolveWith((states) {
                          // if (states.contains(MaterialState.selected)) {
                          //   return Colors.white; // Set the background color when checked
                          // }
                          return Colors.white;// Use the default background color when unchecked
                        }),
                        value: isAgeConfirmed,
                        checkColor: Colors.green,
                        activeColor: Colors.green,
                        onChanged: (value) {
                          setState(() {
                            isAgeConfirmed = value!;
                          });
                        },
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        visualDensity: VisualDensity.compact,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                            color: Colors.black     , // Set the desired border color here
                            width: 2.0, // Set the desired border width here
                          ),
                          borderRadius: BorderRadius.circular(4.0), // Set the desired border radius here
                        ),
                      ),
                      Text('I confirm that I am 18+ years in age',style: TextStyle(color: Colors.white,
                          fontSize: 12,fontWeight: FontWeight.bold),)
                    ],
                  ),

              SizedBox(height: 5,),
                  InkWell(
                    onTap: () async{
                      if (_phoneController.text =="" && _phoneController.text.isEmpty) {
                        Get.snackbar(
                          "Required Field",
                          "Please enter your mobile number",
                          icon: Icon(
                            Icons.phone,
                            color: Colors.red,
                          ),
                          backgroundColor: Colors.white,
                          colorText: Colors.red[900],
                        );
                      }else if (!isAgeConfirmed){
                        Get.snackbar(
                          "Required Field",
                          "Please click on Checkbox to confirm",
                          icon: Icon(
                            Icons.check,
                            color: Colors.red,
                          ),
                          backgroundColor: Colors.white,
                          colorText: Colors.red[900],
                        );
                      } else if(_phoneController.text.length !=10 &&_phoneController.text.length <10) {
                        Get.snackbar(
                          "",
                          "Please Enter only Ten digit number",
                          icon: Icon(
                            Icons.phone,
                            color: Colors.red,
                          ),
                          backgroundColor: Colors.white,
                          colorText: Colors.red[900],
                        );
                      }
                      else{
                        signUp(_phoneController.text);
                      }
                      },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 6,right: 6),
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(12)
                        ),
                        child: Center(
                          child: _isLoading
                              ? CircularProgressIndicator(color: Colors.white)
                              : CustomPaddedText(
                            text: 'CONTINUE',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                        ),
                      ),
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.all(6.0),
                  child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Get offers and updates on Whatsapp',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Switch(
                      value: receiveUpdates,
                      onChanged: (value) {
                        setState(() {
                          receiveUpdates = value;
                        });
                      },
                      activeColor: Colors.green, // Set the color of the active switch
                    ),
                  ],
                  ),
                ),
              // InkWell(
              //   onTap: () async {
              //     // signInWithGoogle();
              //     var user = await LoginAPi.login();
              //     if (user != null) {
              //       print('Login successfully!!!!!');
              //       print("User::::::::::"+user.id);
              //       showAlert();
              //       print(user.photoUrl);
              //       print(user.email.toString());
              //       final SharedPreferences sp = await SharedPreferences.getInstance();
              //       sp.setString('email_user', user.email.toString());
              //       sp.setString('user_name', user.displayName.toString());
              //       sp.setString('user_photo', user.photoUrl.toString());
              //       print("user_name:::: "+user.displayName.toString());
              //       print("user_name:::: "+user.photoUrl.toString());
              //     }
              //   },
              //   child: Container(
              //     height: 50,
              //     width: 50,
              //     decoration: BoxDecoration(
              //       image: DecorationImage(image: AssetImage(ImageAssets.Google),),
              //       shape: BoxShape.circle,
              //     ),
              //   ),
              // ),
                ],
              ) ,
             )
           ),
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Align(
              alignment: Alignment.topCenter,
              child: CustomPaddedText(
                text: 'GOOGLY11',
                style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
            ),
          ),
         ]
       )
     );
    }

  Future<void> signUp(String phone) async {
    setState(() {
      _isLoading = true;
    });
    final String apiUrl = 'https://admin.googly11.in/api/signup';

    // Set up the request headers
    Map<String, String> headers = {
      'Accept': 'application/json',
    };

    // Set up the request body
    Map<String, String> body = {
      'phone': phone,
    };

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: headers,
        body: body,
      );
      setState(() {
        _isLoading = false;
      });
      if (response.statusCode == 200) {
        LoginOtpModel otpModel=LoginOtpModel.fromJson(jsonDecode(response.body));
        print('Response: ${response.body}');
        print('Response: ${otpModel.otp}');
        if(otpModel.status==1){
          Navigator.push(context, MaterialPageRoute(builder: (context) => OtpView(mobile_number: _phoneController.text)));
          Fluttertoast.showToast(msg: "Otp send successfully");
        }else if(otpModel.status==0){
          Fluttertoast.showToast(msg: "Please Enter correct number");
        }
      } else {
        // Handle error response
        print('API call failed with status ${response.statusCode}');
        print('Response: ${response.body}');
      }
    } catch (e) {
      // Handle exceptions
      print('Error: $e');
    }
  }

  void showAlert() async {
    QuickAlert.show(
      onConfirmBtnTap: () {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => MyBottomNavigationBar()),
              (route) => false,
        );

      },
      context: context,
      title: 'Login Successfully',
      type: QuickAlertType.success,
    );
  }
  Future<void> signInWithGoogle() async {
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
    final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth?.accessToken,
      idToken: googleAuth?.idToken,
    );
    FirebaseAuth.instance.signInWithCredential(credential);
    showAlert();
  }

}

