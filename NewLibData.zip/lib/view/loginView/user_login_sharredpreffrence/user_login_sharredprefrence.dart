import 'package:shared_preferences/shared_preferences.dart';

// class SharedPreferencesService {
//   static const String userEmailKey = 'user_email';
//
//   static const String emailAnddetail= 'email_detail';
//
//   static Future<void> saveUserEmail(String email) async {
//     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.setString(userEmailKey, email);
//   }
//
//   static Future<String?> getUserEmail() async {
//     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     return prefs.getString(userEmailKey);
//   }
//
//
//   static Future<String?> saveUserData() async {
//     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     return prefs.getString(emailAnddetail);
//   }
//
//
// }
