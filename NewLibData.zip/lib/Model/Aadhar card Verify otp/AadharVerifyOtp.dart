import 'Result.dart';

class AadharVerifyOtp {
  AadharVerifyOtp({
      required this.code,
      required this.result,});

  AadharVerifyOtp.fromJson(dynamic json) {
    code = json['code'];
    result = json['result'] != null ? Result.fromJson(json['result']) : null;
  }
  int code=0;
  Result? result;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['code'] = code;
    if (result != null) {
      map['result'] = result!.toJson();
    }
    return map;
  }

}