import 'PlayerDetails.dart';

class Players {
  Players({
    required this.playerDetails,
  });

  Players.fromJson(dynamic json) {
    teamPlayerID = json['teamPlayerID'];
    teamID = json['teamID'];
    playerID = json['playerID'];
    captain = json['captain'];
    viceCaptain = json['viceCaptain'];
    playerDetails = json['playerDetails'] != null ? PlayerDetails.fromJson(json['playerDetails']) : null;
  }
  int teamPlayerID = 0;
  int teamID  = 0;
  int playerID = 0;
  int captain = 0;
  int viceCaptain = 0;
  PlayerDetails? playerDetails;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['teamPlayerID'] = teamPlayerID;
    map['teamID'] = teamID;
    map['playerID'] = playerID;
    map['captain'] = captain;
    map['viceCaptain'] = viceCaptain;
    if (playerDetails != null) {
      map['playerDetails'] = playerDetails!.toJson();
    }
    return map;
  }

}