import 'PrizeDistributions.dart';

class Data {
  Data({
    // required  this.id,
    //   this.matchId,
    // required this.contestName,
    // required this.totalTeamsAllowed,
    // required this.entryFee,
    // required   this.firstPrize,
    // required this.status,
    // required  this.contestType,
    // required  this.contestDescription,
    // required  this.winnerCriteria,
    //   this.scoringSystem,
    // required  this.userParticipant,
    // required  this.appCharge,
    // required  this.useBonus,
    // required  this.bonusContest,
    // required  this.visibility,
    //   this.startTime,
    //   this.endTime,
    // required   this.contestStatus,
    // required   this.createdAt,
    // required   this.updatedAt,
    required   this.prizeDistributions,});

  Data.fromJson(dynamic json) {
    // id = json['id'] ?? 0;
    // matchId = json['match_id']?? 0;
    // contestName = json['contest_name'] ?? '';
    // totalTeamsAllowed = json['total_teams_allowed'] ?? 0;
    // entryFee = json['entry_fee'] ?? '';
    // firstPrize = json['first_prize'] ?? '';
    // status = json['status'] ?? '';
    // contestType = json['contest_type'] ?? '';
    // contestDescription = json['contest_description'] ?? '';
    // winnerCriteria = json['winner_criteria'] ?? 0;
    // scoringSystem = json['scoring_system'] ?? '';
    // userParticipant = json['user_participant'] ?? 0;
    // appCharge = json['app_charge'] ?? 0;
    // useBonus = json['use_bonus'] ?? 0;
    // bonusContest = json['bonus_contest'] ?? 0;
    // visibility = json['visibility'] ?? '';
    // startTime = json['start_time'];
    // endTime = json['end_time'];
    // contestStatus = json['contest_status'] ?? 0;
    // createdAt = json['created_at'];
    // updatedAt = json['updated_at'];
    if (json['prize_distributions'] != null) {
      prizeDistributions = [];
      json['prize_distributions'].forEach((v) {
        prizeDistributions!.add(PrizeDistributions.fromJson(v));
      });
    }
  }
  // int id= 0;
  // dynamic matchId;
  // String contestName = '';
  // int totalTeamsAllowed =0;
  // String entryFee = '';
  // String firstPrize = '';
  // String status = '';
  // String contestType = '';
  // String contestDescription = '';
  // int winnerCriteria  = 0;
  // dynamic scoringSystem;
  // int userParticipant  = 0;
  // int appCharge = 0;
  // int useBonus = 0;
  // int bonusContest = 0;
  // String visibility = '';
  // dynamic startTime;
  // dynamic endTime;
  // int contestStatus = 0;
  // String createdAt = '';
  // String updatedAt = '';
  List<PrizeDistributions>? prizeDistributions;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    // map['id'] = id;
    // map['match_id'] = matchId;
    // map['contest_name'] = contestName;
    // map['total_teams_allowed'] = totalTeamsAllowed;
    // map['entry_fee'] = entryFee;
    // map['first_prize'] = firstPrize;
    // map['status'] = status;
    // map['contest_type'] = contestType;
    // map['contest_description'] = contestDescription;
    // map['winner_criteria'] = winnerCriteria;
    // map['scoring_system'] = scoringSystem;
    // map['user_participant'] = userParticipant;
    // map['app_charge'] = appCharge;
    // map['use_bonus'] = useBonus;
    // map['bonus_contest'] = bonusContest;
    // map['visibility'] = visibility;
    // map['start_time'] = startTime;
    // map['end_time'] = endTime;
    // map['contest_status'] = contestStatus;
    // map['created_at'] = createdAt;
    // map['updated_at'] = updatedAt;
    if (prizeDistributions != null) {
      map['prize_distributions'] = prizeDistributions!.map((v) => v.toJson()).toList();
    }
    return map;
  }

}