// import 'Result.dart';
//
// class CricketEvent {
//   int success;
//   List<EventResult> result;
//
//   CricketEvent({required this.success, required this.result});
//
//   factory CricketEvent.fromJson(Map<String, dynamic> json) {
//     var resultList = json['result'] as List;
//     List<EventResult> events =
//     resultList.map((event) => EventResult.fromJson(event)).toList();
//
//     return CricketEvent(
//       success: json['success'],
//       result: events,
//     );
//   }
// }