import 'Result.dart';

class PanCardModel {
  PanCardModel({
     required this.code,
    required this.message,
     required this.result,});

  PanCardModel.fromJson(dynamic json) {
    code = json['code'];
    message=json['message'] ?? "";
    result = json['result'] != null ? Result.fromJson(json['result']) : null;
  }
  int code=0;
  String message='';
  Result? result;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['code'] = code;
    map['message']=message;
    if (result != null) {
      map['result'] = result!.toJson();
    }
    return map;
  }

}